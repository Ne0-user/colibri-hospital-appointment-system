class Usuario:
    def __init__(self,ID,nombre,apellido,fecha_na,usuario,contraseña):
        self.id=ID
        self.nombre=nombre
        self.apellido=apellido
        self.